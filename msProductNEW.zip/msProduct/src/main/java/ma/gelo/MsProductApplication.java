package ma.gelo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ma.gelo.dao.ProductRepository;
import ma.gelo.entities.Product;

@SpringBootApplication
public class MsProductApplication implements CommandLineRunner {
	
	@Autowired
	ProductRepository pr;
	
	public static void main(String[] args) {
		SpringApplication.run(MsProductApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		pr.save(new Product(null, "McBook", 8900.23, "informatique"));
		pr.save(new Product(null, "TV", 5900.23, "electromenager"));
		pr.save(new Product(null, "Printer", 1900.23, "informatique"));
		
		System.out.println("=============== all products=============");
		for (Product prd : pr.findAll()) {
			System.out.println(prd.toString());
		}
		
		System.out.println("=============== one products : 2 =============");
		
			System.out.println(pr.findById(2L).get().toString());
		
			System.out.println("=============== all products informatique=============");
			for (Product prd : pr.findByCategory("Informatique")) {
				System.out.println(prd.toString());
			}
	}

}
